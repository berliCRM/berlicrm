<?php
$mod_strings = Array (
'INSTALL_SUCCESS' => 'The extension module has been installed successfully!',

);

?>
