<?php
$languageStrings = Array (
	'berliWidgets' => 'berliWidgets',
	'LBL_RELATED_TO' => 'bezogen auf',
	'LBL_NO_RECORDS' => 'keine Daten',
	'LBL_WRITE_ACCESS_FOR' => 'Sie haben keine Erstellrechte für ',
	'LBL_MODULE_DENIED' => 'Der Modulzugang ist gesperrt.',
	'LBL_PROBLEM_UPLOAD' => 'Es gab ein Update Problem, bitte die Seite neu laden und nochmal versuchen.',
);

?>