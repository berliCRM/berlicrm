<?php
$languageStrings = Array (
	'berliWidgets' => 'berliWidgets',
	'LBL_RELATED_TO' => 'bezogen auf',
	'LBL_NO_RECORDS' => 'keine Daten',

);

?>