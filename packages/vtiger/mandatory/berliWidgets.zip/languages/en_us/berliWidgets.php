<?php
$languageStrings = Array (
	'berliWidgets' => 'berliWidgets',
	'LBL_RELATED_TO' => 'related to',
	'LBL_NO_RECORDS' => 'no data',
	'LBL_WRITE_ACCESS_FOR' => 'You do not have create privileges for ',
	'LBL_MODULE_DENIED' => 'The module access is denied.',
	'LBL_PROBLEM_UPLOAD' => 'There has been an upload problem. Please reload the page an try again.',
);

?>