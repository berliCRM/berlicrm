<?php
$languageStrings = Array (
	'berliWidgets' => 'berliWidgets',
	'LBL_RELATED_TO' => 'related to',
	'LBL_NO_RECORDS' => 'no data',

);

?>