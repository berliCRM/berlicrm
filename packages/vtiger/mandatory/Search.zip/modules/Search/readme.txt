This module is a result of joint work of several community members initiated by yetiforce and dubwise as listed in the module headers. 
The following functions are provided to the CRM's global search function:

- search all content in all modules
- search selected content in all modules
- search all content in selected modules
- search selected content in selected modules

You may also decide what is displayed as search result.

Installation:
Use the Module Manager to install this module. Unfortunately, this module requires modifications of the CRM's core files. Therefore you have to copy the content of the /vtiger directory manually to finish the installation.
After installation the search is set to:
- search all content in all modules


Enjoy it.
crm-now GmbH
