<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 * reviewed by crm-now GmbH
 *************************************************************************************/
$languageStrings = array(
	'LBL_CONTACTDETAILS' => 'Contact Details',
	'LBL_COPY' => 'Copy',
	'LBL_SHOW_CONTACTDETAILS' => 'Show Contact Details',
	'LBL_COPY_CONTACTDETAILS' => 'Copy Contact Details',
	'LBL_TEXT_COPIED' => 'Text copied.',
);

$jsLanguageStrings = array(
);
