<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 * reviewed by crm-now GmbH
 *************************************************************************************/
$languageStrings = array(
    'LBL_CONTACTDETAILS' => 'Kontaktdaten',
	'LBL_COPY' => 'Kopieren',
	'LBL_SHOW_CONTACTDETAILS' => 'Zeige Kontaktdaten',
	'LBL_COPY_CONTACTDETAILS' => 'Kopiere Kontaktdaten',
	'LBL_TEXT_COPIED' => 'Text kopiert.',
);

$jsLanguageStrings = array(
);
