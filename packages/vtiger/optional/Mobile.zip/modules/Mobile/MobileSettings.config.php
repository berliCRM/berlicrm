<?php
$displayed_modules= array(
	'Contacts',
	'Accounts',
	'Leads',
	'Calendar',
	'Potentials',
	'HelpDesk',
	'Events',
	'Quotes',
	'SalesOrder'
);
$modules_with_comments= array(
	'Contacts',
	'Accounts',
	'Leads',
	'Potentials',
	'HelpDesk',
);

$config_settings = array(
'language' => 'de_de',
//for Calendar: day, week, month, year
'calendarview' => 'week',
'compactcalendar' => 'on',
);
?>