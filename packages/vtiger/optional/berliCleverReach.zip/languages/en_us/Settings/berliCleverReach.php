<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 * Modified and improved by crm-now.de
 *************************************************************************************/
$languageStrings = array(
		'LBL_CLEVERREACH_DESCRIPTION' => 'Manage CleverReach access data and settings',
	);
	
	
	$jsLanguageStrings = array(
		'CR_CREDS_REQUIRED' => 'Please enter your complete CleverReach credentials.',
		'LBL_SUCCESS' => 'Your CleverReach settings have been saved.',
		'LBL_CONFIRM_DELETION' => 'This will delete the current CleverReach API connection. Are you sure?',
		'LBL_SAVE_ERROR' => 'Error!',
	);
	
?>